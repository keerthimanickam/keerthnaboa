package com.boa.kyc.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

	private CustomerServiceProxy customerServiceProxy;
	
	@GetMapping(value="/getfeigncustomers")
	public String getFeignCustomerData() {
		return "";
	}
}
